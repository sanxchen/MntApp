
// All Rights Reserved , Copyright @ Iooin 2017
// Software Developers @ Iooin 2017


using Carlzhu.Iooin.Entity;


using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Carlzhu.Iooin.Business
{
    /// <summary>
    /// Apparatus
    
    ///		<name>Carlzhu</name>
    ///		<date>2017.02.17 10:22</date>
    
    /// </summary>
    public class ApparatusBll : RepositoryFactory<Apparatus>
    {
    }
}