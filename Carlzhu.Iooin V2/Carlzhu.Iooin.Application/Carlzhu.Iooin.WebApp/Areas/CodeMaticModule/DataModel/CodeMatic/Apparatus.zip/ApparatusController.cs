using Carlzhu.Iooin.Business;
using Carlzhu.Iooin.Entity;

using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Carlzhu.Iooin.WebApp.Areas.CommonModule.Controllers
{
    /// <summary>
    /// Apparatus������
    /// </summary>
    public class ApparatusController : PublicController<Apparatus>
    {
    }
}