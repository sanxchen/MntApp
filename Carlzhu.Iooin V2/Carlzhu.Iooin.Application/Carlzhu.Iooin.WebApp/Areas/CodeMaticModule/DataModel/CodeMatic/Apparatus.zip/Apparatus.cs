
// All Rights Reserved , Copyright @ Iooin 2017
// Software Developers @ Iooin 2017


using Carlzhu.Iooin.DataAccess.Attributes;

using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Carlzhu.Iooin.Entity
{
    /// <summary>
    /// Apparatus
    
    ///		<name>Carlzhu</name>
    ///		<date>2017.02.17 10:22</date>
    
    /// </summary>
    [Description("Apparatus")]
    [PrimaryKey("MntNo")]
    public class Apparatus : BaseEntity
    {
    }
}