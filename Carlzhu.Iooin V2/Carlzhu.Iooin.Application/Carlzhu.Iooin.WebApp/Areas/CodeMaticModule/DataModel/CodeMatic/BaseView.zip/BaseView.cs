
// All Rights Reserved , Copyright @ Iooin 2016
// Software Developers @ Iooin 2016


using Carlzhu.Iooin.DataAccess.Attributes;
using Carlzhu.Iooin.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Carlzhu.Iooin.Entity
{
    /// <summary>
    /// BaseView
    
    ///		<name>Carlzhu</name>
    ///		<date>2016.11.09 15:58</date>
    
    /// </summary>
    [Description("BaseView")]
    [PrimaryKey("ModuleId")]
    public class BaseView : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ViewId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ViewId")]
        public string ViewId { get; set; }
        /// <summary>
        /// ModuleId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModuleId")]
        public string ModuleId { get; set; }
        /// <summary>
        /// ParentId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ParentId")]
        public string ParentId { get; set; }
        /// <summary>
        /// FieldName
        /// </summary>
        /// <returns></returns>
        [DisplayName("FieldName")]
        public string FieldName { get; set; }
        /// <summary>
        /// FullName
        /// </summary>
        /// <returns></returns>
        [DisplayName("FullName")]
        public string FullName { get; set; }
        /// <summary>
        /// ShowName
        /// </summary>
        /// <returns></returns>
        [DisplayName("ShowName")]
        public string ShowName { get; set; }
        /// <summary>
        /// ColumnWidth
        /// </summary>
        /// <returns></returns>
        [DisplayName("ColumnWidth")]
        public int? ColumnWidth { get; set; }
        /// <summary>
        /// TextAlign
        /// </summary>
        /// <returns></returns>
        [DisplayName("TextAlign")]
        public string TextAlign { get; set; }
        /// <summary>
        /// AllowShow
        /// </summary>
        /// <returns></returns>
        [DisplayName("AllowShow")]
        public int? AllowShow { get; set; }
        /// <summary>
        /// AllowDerive
        /// </summary>
        /// <returns></returns>
        [DisplayName("AllowDerive")]
        public int? AllowDerive { get; set; }
        /// <summary>
        /// CustomSwitch
        /// </summary>
        /// <returns></returns>
        [DisplayName("CustomSwitch")]
        public string CustomSwitch { get; set; }
        /// <summary>
        /// Enabled
        /// </summary>
        /// <returns></returns>
        [DisplayName("Enabled")]
        public int? Enabled { get; set; }
        /// <summary>
        /// SortCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("SortCode")]
        public int? SortCode { get; set; }
        /// <summary>
        /// CreateDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateDate")]
        public DateTime? CreateDate { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.ModuleId = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
                                }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.ModuleId = KeyValue;
                                            }
        #endregion
    }
}