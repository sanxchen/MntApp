using Carlzhu.Iooin.Business;
using Carlzhu.Iooin.Entity;
using Carlzhu.Iooin.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Carlzhu.Iooin.WebApp.Areas.CommonModule.Controllers
{
    /// <summary>
    /// Published������
    /// </summary>
    public class PublishedController : PublicController<Published>
    {
    }
}