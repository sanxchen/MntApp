
// All Rights Reserved , Copyright @ Iooin 2016
// Software Developers @ Iooin 2016


using Carlzhu.Iooin.Entity;
using Carlzhu.Iooin.Repository;
using Carlzhu.Iooin.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Carlzhu.Iooin.Business
{
    /// <summary>
    /// Published
    
    ///		<name>Carlzhu</name>
    ///		<date>2016.11.09 15:52</date>
    
    /// </summary>
    public class PublishedBll : RepositoryFactory<Published>
    {
    }
}