
// All Rights Reserved , Copyright @ Iooin 2016
// Software Developers @ Iooin 2016


using Carlzhu.Iooin.DataAccess.Attributes;
using Carlzhu.Iooin.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Carlzhu.Iooin.Entity
{
    /// <summary>
    /// Published
    
    ///		<name>Carlzhu</name>
    ///		<date>2016.11.09 15:52</date>
    
    /// </summary>
    [Description("Published")]
    [PrimaryKey("EmpNo")]
    public class Published : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// PubishedGuid
        /// </summary>
        /// <returns></returns>
        [DisplayName("PubishedGuid")]
        public string PubishedGuid { get; set; }
        /// <summary>
        /// FormNo
        /// </summary>
        /// <returns></returns>
        [DisplayName("FormNo")]
        public string FormNo { get; set; }
        /// <summary>
        /// PublishType
        /// </summary>
        /// <returns></returns>
        [DisplayName("PublishType")]
        public int? PublishType { get; set; }
        /// <summary>
        /// PublishTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("PublishTime")]
        public DateTime? PublishTime { get; set; }
        /// <summary>
        /// EmpNo
        /// </summary>
        /// <returns></returns>
        [DisplayName("EmpNo")]
        public string EmpNo { get; set; }
        /// <summary>
        /// PublishVer
        /// </summary>
        /// <returns></returns>
        [DisplayName("PublishVer")]
        public string PublishVer { get; set; }
        /// <summary>
        /// IsDel
        /// </summary>
        /// <returns></returns>
        [DisplayName("IsDel")]
        public bool? IsDel { get; set; }
        /// <summary>
        /// IsPass
        /// </summary>
        /// <returns></returns>
        [DisplayName("IsPass")]
        public bool? IsPass { get; set; }
        /// <summary>
        /// Identity
        /// </summary>
        /// <returns></returns>
        [DisplayName("Identity")]
        public string Identity { get; set; }
        /// <summary>
        /// CustomerNo
        /// </summary>
        /// <returns></returns>
        [DisplayName("CustomerNo")]
        public string CustomerNo { get; set; }
        /// <summary>
        /// FileGroup
        /// </summary>
        /// <returns></returns>
        [DisplayName("FileGroup")]
        public string FileGroup { get; set; }
        /// <summary>
        /// ProductNo
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductNo")]
        public string ProductNo { get; set; }
        /// <summary>
        /// Visit
        /// </summary>
        /// <returns></returns>
        [DisplayName("Visit")]
        public int? Visit { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.EmpNo = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.EmpNo = KeyValue;
                                            }
        #endregion
    }
}