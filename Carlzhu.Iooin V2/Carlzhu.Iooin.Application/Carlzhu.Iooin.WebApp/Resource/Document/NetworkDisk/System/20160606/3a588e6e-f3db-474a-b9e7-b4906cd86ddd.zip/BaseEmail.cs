
// All Rights Reserved , Copyright @ Iooin 2016
// Software Developers @ Iooin 2016


using Carlzhu.Iooin.DataAccess.Attributes;
using Carlzhu.Iooin.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Carlzhu.Iooin.Entity
{
    /// <summary>
    /// BaseEmail
    
    ///		<name>Carlzhu</name>
    ///		<date>2016.06.05 20:35</date>
    
    /// </summary>
    [Description("BaseEmail")]
    [PrimaryKey("Category")]
    public class BaseEmail : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// EmailId
        /// </summary>
        /// <returns></returns>
        [DisplayName("EmailId")]
        public string EmailId { get; set; }
        /// <summary>
        /// ParentId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ParentId")]
        public string ParentId { get; set; }
        /// <summary>
        /// Category
        /// </summary>
        /// <returns></returns>
        [DisplayName("Category")]
        public string Category { get; set; }
        /// <summary>
        /// Theme
        /// </summary>
        /// <returns></returns>
        [DisplayName("Theme")]
        public string Theme { get; set; }
        /// <summary>
        /// ThemeColour
        /// </summary>
        /// <returns></returns>
        [DisplayName("ThemeColour")]
        public string ThemeColour { get; set; }
        /// <summary>
        /// Content
        /// </summary>
        /// <returns></returns>
        [DisplayName("Content")]
        public string Content { get; set; }
        /// <summary>
        /// Addresser
        /// </summary>
        /// <returns></returns>
        [DisplayName("Addresser")]
        public string Addresser { get; set; }
        /// <summary>
        /// SendDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("SendDate")]
        public DateTime? SendDate { get; set; }
        /// <summary>
        /// IsAccessory
        /// </summary>
        /// <returns></returns>
        [DisplayName("IsAccessory")]
        public int? IsAccessory { get; set; }
        /// <summary>
        /// Priority
        /// </summary>
        /// <returns></returns>
        [DisplayName("Priority")]
        public int? Priority { get; set; }
        /// <summary>
        /// Receipt
        /// </summary>
        /// <returns></returns>
        [DisplayName("Receipt")]
        public int? Receipt { get; set; }
        /// <summary>
        /// IsDelayed
        /// </summary>
        /// <returns></returns>
        [DisplayName("IsDelayed")]
        public int? IsDelayed { get; set; }
        /// <summary>
        /// DelayedTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("DelayedTime")]
        public DateTime? DelayedTime { get; set; }
        /// <summary>
        /// State
        /// </summary>
        /// <returns></returns>
        [DisplayName("State")]
        public int? State { get; set; }
        /// <summary>
        /// DeleteMark
        /// </summary>
        /// <returns></returns>
        [DisplayName("DeleteMark")]
        public int? DeleteMark { get; set; }
        /// <summary>
        /// CreateDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateDate")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// CreateUserId
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateUserId")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// CreateUserName
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateUserName")]
        public string CreateUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.Category = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.Category = KeyValue;
                                            }
        #endregion
    }
}