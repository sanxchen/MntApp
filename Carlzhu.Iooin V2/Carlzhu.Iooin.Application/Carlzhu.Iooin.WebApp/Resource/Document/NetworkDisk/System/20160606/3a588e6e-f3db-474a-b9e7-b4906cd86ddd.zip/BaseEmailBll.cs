
// All Rights Reserved , Copyright @ Iooin 2016
// Software Developers @ Iooin 2016


using Carlzhu.Iooin.Entity;
using Carlzhu.Iooin.Repository;
using Carlzhu.Iooin.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace Carlzhu.Iooin.Business
{
    /// <summary>
    /// BaseEmail
    
    ///		<name>Carlzhu</name>
    ///		<date>2016.06.05 20:35</date>
    
    /// </summary>
    public class BaseEmailBll : RepositoryFactory<BaseEmail>
    {
    }
}